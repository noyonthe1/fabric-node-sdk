## Maintainers

This repository is part of the Fabric project.
Please consult [Fabric's MAINTAINERS documentation](https://github.com/hyperledger/fabric/blob/master/docs/MAINTAINERS.md) for the list of people maintaining this repository.
